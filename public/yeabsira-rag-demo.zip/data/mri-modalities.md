# MRI modalities for brain tumor segmentation

MRI is not a single image. A scanner can be run with different settings (sequences) that each
highlight tissue differently. Brain tumor segmentation, such as in the widely used BraTS
benchmark, usually relies on four standard modalities captured for the same patient.

## The four common sequences

- **T1**: a baseline anatomical scan. Good general structure; tumors are often hard to separate
  from healthy tissue on T1 alone.
- **T1 with contrast (T1c / T1Gd)**: taken after a gadolinium contrast agent is injected. The
  contrast accumulates where the blood-brain barrier is broken down, so the active, enhancing
  rim of a tumor lights up brightly.
- **T2**: highlights fluid and tends to make tumor and edema (swelling) appear bright.
- **FLAIR** (Fluid-Attenuated Inversion Recovery): like T2 but with the bright signal from
  normal cerebrospinal fluid suppressed, which makes it easier to see edema and lesions near
  fluid-filled spaces.

## Why use several at once

Each sequence shows part of the picture. The enhancing tumor core is clearest on T1c, while the
surrounding edema is clearest on T2 and FLAIR. Tumor sub-regions — the enhancing tumor, the
necrotic core, and the surrounding edema — are best separated by combining the modalities.

For this reason, segmentation models usually take all the modalities together as a
multi-channel input: the four co-registered scans are stacked so the network sees them as
different channels of the same volume, the way an RGB image stacks three colour channels. The
model can then learn to combine evidence across modalities to label each voxel.
