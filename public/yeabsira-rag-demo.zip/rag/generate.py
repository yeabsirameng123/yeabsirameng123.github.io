"""Generate a grounded answer from a question and retrieved context.

Default: a local flan-t5 model (no API key, runs on CPU).
Optional: if OPENAI_API_KEY is set and the openai package is installed, use that instead
for higher-quality answers. The optional path never breaks the default — any failure falls
straight back to the local model.
"""
import os

GEN_MODEL = "google/flan-t5-base"
MAX_CONTEXT_CHARS = 1800
MAX_NEW_TOKENS = 220

_generator = None


def _get_local_generator():
    global _generator
    if _generator is None:
        from transformers import pipeline
        _generator = pipeline("text2text-generation", model=GEN_MODEL)
    return _generator


def _build_prompt(question, contexts):
    context = "\n\n".join(contexts)[:MAX_CONTEXT_CHARS]
    return (
        "Answer the question using only the context below. "
        "Be concise and specific. If the answer is not in the context, say "
        "you don't have enough information.\n\n"
        f"Context:\n{context}\n\n"
        f"Question: {question}\n"
        "Answer:"
    )


def _generate_openai(prompt):
    """Optional higher-quality path. Returns None if unavailable so we can fall back."""
    if not os.environ.get("OPENAI_API_KEY"):
        return None
    try:
        from openai import OpenAI
        client = OpenAI()
        resp = client.chat.completions.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=MAX_NEW_TOKENS,
        )
        return resp.choices[0].message.content.strip()
    except Exception:
        return None


def generate_answer(question, contexts):
    prompt = _build_prompt(question, contexts)

    hosted = _generate_openai(prompt)
    if hosted:
        return hosted

    out = _get_local_generator()(
        prompt, max_new_tokens=MAX_NEW_TOKENS, truncation=True
    )
    return out[0]["generated_text"].strip()
