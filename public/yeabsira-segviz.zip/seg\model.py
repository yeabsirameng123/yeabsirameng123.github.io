"""Load a SegFormer model and turn an image into a per-pixel class map."""

# Any SegFormer semantic-segmentation checkpoint on the Hub works here.
# ADE20K (150 classes) is a good general-purpose scene parser.
MODEL_NAME = "nvidia/segformer-b0-finetuned-ade-512-512"

_model = None
_processor = None


def load():
    """Load the model and image processor once, then reuse them."""
    global _model, _processor
    if _model is None:
        from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
        _processor = SegformerImageProcessor.from_pretrained(MODEL_NAME)
        _model = SegformerForSemanticSegmentation.from_pretrained(MODEL_NAME)
        _model.eval()
    return _model, _processor


def segment(image):
    """Run segmentation on a PIL image.

    Returns (class_map, id2label) where class_map is a HxW int array of class ids
    matching the original image size, and id2label maps ids to human-readable names.
    """
    import torch

    model, processor = load()
    rgb = image.convert("RGB")
    inputs = processor(images=rgb, return_tensors="pt")

    with torch.no_grad():
        outputs = model(**inputs)

    # upsample the prediction back to the original (height, width)
    seg = processor.post_process_semantic_segmentation(
        outputs, target_sizes=[(rgb.height, rgb.width)]
    )[0]

    class_map = seg.cpu().numpy().astype("int32")
    return class_map, model.config.id2label
