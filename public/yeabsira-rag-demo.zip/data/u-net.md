# U-Net

The U-Net is a convolutional neural network designed for image segmentation, originally
introduced for biomedical images. Its name comes from its U-shaped architecture: a contracting
(encoder) path on the left and an expanding (decoder) path on the right.

## How it is built

The encoder works like a typical classification CNN. It repeatedly applies convolutions and
downsampling (pooling or strided convolutions). With each downsampling step the spatial
resolution shrinks while the number of feature channels grows, so the network captures
increasingly abstract context about what is in the image.

The decoder reverses this. It upsamples the feature maps step by step back toward the original
resolution, applying convolutions along the way, until it can output a prediction for every
pixel.

## Skip connections

The defining feature of the U-Net is its skip connections. At each level, the high-resolution
feature maps from the encoder are concatenated onto the matching level of the decoder. This
matters because downsampling throws away precise location information. The skip connections
hand that fine spatial detail back to the decoder, which lets the network produce sharp,
well-localized boundaries instead of blurry blobs.

## Why it works well for segmentation

Segmentation needs both *what* (semantic understanding of the object) and *where* (precise
boundaries). The encoder supplies the what and the skip connections preserve the where. U-Net
also trains well from relatively few annotated images, which is important in medical imaging
where labels are expensive and require expert annotation. The final layer typically uses a
1x1 convolution to map features to the number of target classes, followed by a softmax or
sigmoid to produce per-pixel class probabilities.
