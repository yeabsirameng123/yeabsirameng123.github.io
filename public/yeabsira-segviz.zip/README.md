---
title: SegViz - Semantic Segmentation
emoji: image
colorFrom: indigo
colorTo: purple
sdk: gradio
sdk_version: 4.44.0
app_file: app.py
pinned: false
license: mit
---

# SegViz - semantic segmentation in the browser

SegViz is a live semantic-segmentation app. Upload a photo, and a SegFormer
transformer labels every pixel with the scene class it belongs to. The app
returns a color overlay, a fade slider, and a ranked coverage breakdown showing
how much of the frame is road, sky, building, person, vegetation, furniture, and
other ADE20K classes.

This is built to run on a free CPU Hugging Face Space with no API keys and no
hosted inference endpoint. The model is
`nvidia/segformer-b0-finetuned-ade-512-512`, a compact SegFormer-B0 checkpoint
fine-tuned on ADE20K scene parsing.

## Why it matters

Semantic segmentation is the same core computer-vision problem behind medical
image labeling, robotics perception, autonomous-scene understanding, and visual
analytics: classify every pixel, not just the whole image. This browser demo
connects directly to my published 3D U-Net brain-tumor segmentation work while
showing a product-style interface someone can actually use.

## What the app demonstrates

- Transformer-based dense prediction with Hugging Face Transformers.
- Per-pixel class maps upsampled back to the original image size.
- Deterministic color palettes and alpha-blended overlays.
- Coverage analytics computed from the segmentation mask.
- Cached masks so the overlay-strength slider re-blends instantly without
  running model inference again.
- A Gradio UI that can deploy to Hugging Face Spaces on free CPU hardware.

## Architecture

```text
uploaded image
  -> SegFormer image processor
  -> SegFormer-B0 semantic segmentation model
  -> per-pixel logits
  -> upsampled class map at the original image size
  -> color overlay + coverage percentages
```

## Deploy to Hugging Face Spaces

1. Create a new Space at https://huggingface.co/spaces.
2. Choose Gradio as the SDK and CPU basic as the hardware.
3. Upload every file in this repository, keeping the `seg/` folder next to
   `app.py`.
4. The first build downloads the model. After that, the app runs locally inside
   the Space.

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

## Project layout

```text
app.py              Gradio interface, state handling, cached re-blending
seg/model.py        Model loading and SegFormer inference
seg/visualize.py    Palette generation, overlay blending, coverage analytics
requirements.txt    Runtime dependencies
```

## Notes

The app is designed for general scene images because ADE20K has 150 everyday
scene classes. For a domain-specific version, change `MODEL_NAME` in
`seg/model.py` to another semantic-segmentation checkpoint from the Hugging Face
Hub.
