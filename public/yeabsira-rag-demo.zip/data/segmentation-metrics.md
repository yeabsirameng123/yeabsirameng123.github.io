# Segmentation metrics

Segmentation quality is measured by comparing the predicted mask against a ground-truth mask
annotated by an expert. Plain pixel accuracy is a poor measure here, because in most medical
scans the structure of interest is tiny compared to the background — a model that predicts
"background everywhere" can score very high accuracy while being useless. The metrics below are
used instead.

## Dice coefficient

The Dice similarity coefficient measures overlap between the predicted region and the ground
truth. It is defined as twice the size of their intersection divided by the sum of their sizes:

Dice = 2 * |Prediction ∩ Ground truth| / (|Prediction| + |Ground truth|)

It ranges from 0 (no overlap) to 1 (perfect overlap). Dice is the most reported metric in
medical image segmentation because it handles class imbalance gracefully — it only cares about
the structure being segmented, not the vast background.

## Intersection over Union (IoU / Jaccard)

IoU, also called the Jaccard index, is the size of the intersection divided by the size of the
union:

IoU = |Prediction ∩ Ground truth| / |Prediction ∪ Ground truth|

It also ranges from 0 to 1 and is closely related to Dice; for the same prediction, IoU is
always less than or equal to Dice.

## Sensitivity and specificity

Sensitivity (recall) is the fraction of true structure voxels the model correctly found.
Specificity is the fraction of true background voxels it correctly left out. Together they
describe whether errors are misses or false alarms.

## Hausdorff distance

The metrics above measure region overlap. Hausdorff distance instead measures boundary error:
it captures the largest distance between the predicted boundary and the true boundary. It is
useful because two masks can have a good Dice score yet still have a stray, badly placed edge,
which a boundary metric will catch.
