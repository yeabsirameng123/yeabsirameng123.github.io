"""Turn a class map into a colour overlay and a coverage breakdown."""
import colorsys
import numpy as np
from PIL import Image


def build_palette(n=256):
    """A deterministic set of visually distinct RGB colours (golden-ratio hue spacing)."""
    palette = []
    for i in range(n):
        hue = (i * 0.61803398875) % 1.0
        sat = 0.62 + 0.18 * ((i // 7) % 2)   # slight variation so neighbours differ
        val = 0.95
        r, g, b = colorsys.hsv_to_rgb(hue, sat, val)
        palette.append((int(r * 255), int(g * 255), int(b * 255)))
    return palette


def colorize(class_map, palette):
    """Map each class id to its colour, producing an HxWx3 uint8 array."""
    h, w = class_map.shape
    out = np.zeros((h, w, 3), dtype=np.uint8)
    for cls in np.unique(class_map):
        out[class_map == cls] = palette[int(cls) % len(palette)]
    return out


def make_overlay(image, class_map, palette, alpha=0.55):
    """Blend the colourised segmentation over the original image."""
    base = np.asarray(image.convert("RGB"), dtype=np.float32)
    color = colorize(class_map, palette).astype(np.float32)

    # guard against any size mismatch
    if color.shape[:2] != base.shape[:2]:
        color_img = Image.fromarray(color.astype(np.uint8)).resize(
            (base.shape[1], base.shape[0]), Image.NEAREST
        )
        color = np.asarray(color_img, dtype=np.float32)

    blended = (1.0 - alpha) * base + alpha * color
    return Image.fromarray(np.clip(blended, 0, 255).astype(np.uint8))


def coverage(class_map, id2label, palette, top=12):
    """Return [(label, '#rrggbb', percent), ...] sorted by how much of the image each class covers."""
    total = class_map.size
    ids, counts = np.unique(class_map, return_counts=True)
    order = np.argsort(-counts)

    rows = []
    for i in order[:top]:
        cls = int(ids[i])
        pct = round(100.0 * counts[i] / total, 1)
        if pct <= 0.0:
            continue
        r, g, b = palette[cls % len(palette)]
        label = id2label.get(cls, str(cls)) if isinstance(id2label, dict) else str(cls)
        rows.append((label, f"#{r:02x}{g:02x}{b:02x}", pct))
    return rows
