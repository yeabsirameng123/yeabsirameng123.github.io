"""Read documents (.txt, .md, .pdf) and split them into overlapping chunks."""
import os


def read_file(path):
    """Return the plain text of a file, or '' if it can't be read."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
            reader = PdfReader(path)
            return "\n\n".join((page.extract_text() or "") for page in reader.pages)
        except Exception:
            return ""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def chunk_text(text, source, size=900, overlap=150):
    """Split text into ~`size`-character chunks, breaking on paragraphs where possible.

    Paragraphs are packed together until they'd exceed `size`. A single paragraph longer
    than `size` is sliced with `overlap` characters of context carried between slices.
    """
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]

    chunks = []
    buffer = ""

    def flush():
        nonlocal buffer
        if buffer.strip():
            chunks.append(buffer.strip())
        buffer = ""

    for para in paragraphs:
        if len(para) > size:
            flush()
            start = 0
            step = max(1, size - overlap)
            while start < len(para):
                chunks.append(para[start:start + size].strip())
                start += step
        elif len(buffer) + len(para) + 2 <= size:
            buffer += ("\n\n" if buffer else "") + para
        else:
            flush()
            buffer = para
    flush()

    return [{"text": c, "source": source} for c in chunks if c]


def load_corpus(paths):
    """Read and chunk every path, returning a flat list of {text, source} dicts."""
    out = []
    for path in paths:
        text = read_file(path)
        if text.strip():
            out.extend(chunk_text(text, os.path.basename(path)))
    return out
