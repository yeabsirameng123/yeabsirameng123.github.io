---
title: Ask My Docs — RAG
emoji: 🧠
colorFrom: indigo
colorTo: blue
sdk: gradio
sdk_version: 4.44.0
app_file: app.py
pinned: false
license: mit
---

# Ask My Docs — a Retrieval-Augmented Generation demo

A small but complete RAG system. Ask a question; it finds the most relevant passages from a
document collection, then has a language model answer **using only those passages** — and
shows you the sources it used, so the answer is grounded instead of made up.

It ships with a built-in knowledge base on **deep learning for medical image segmentation**
(U-Net, 3D U-Net, Dice score, MRI modalities, data augmentation), and you can upload your own
`.txt`, `.md`, or `.pdf` files to ask questions about them instead.

Built by **Yeabsira Dana** — [LinkedIn](https://www.linkedin.com/in/yeabsira-mengistu/).

## How it works

```
        your question
              │
              ▼
   ┌──────────────────────┐   sentence-transformers (all-MiniLM-L6-v2)
   │   embed the question  │   → a 384-dim vector
   └──────────┬───────────┘
              ▼
   ┌──────────────────────┐   FAISS cosine search over pre-embedded
   │  retrieve top passages│   document chunks
   └──────────┬───────────┘
              ▼
   ┌──────────────────────┐   prompt = instructions + retrieved context + question
   │  generate the answer  │   model: google/flan-t5-base (runs locally, CPU)
   └──────────┬───────────┘
              ▼
     grounded answer + the sources it leaned on
```

Everything runs locally on the Space — **no API keys, no paid services.** It's deliberately
framework-light (embeddings + FAISS + a local model wired together by hand) so the mechanics
are visible rather than hidden inside a library. The same pipeline could be swapped onto
LangChain or Haystack, or pointed at a hosted LLM, without changing the structure.

## Deploy it to Hugging Face Spaces (free)

1. Create an account at [huggingface.co](https://huggingface.co), then **New → Space**.
2. Choose **Gradio** as the SDK and **CPU basic (free)** hardware.
3. Upload every file from this folder (keep the `rag/` and `data/` folders intact), or push
   with git. The `README.md` front-matter above tells the Space how to run.
4. The first build downloads the models (~1 GB) — give it a couple of minutes. After that it's
   live at `https://huggingface.co/spaces/your-username/your-space`.

The first answer after a cold start can take ~30–60 seconds while the model loads; answers are
quick after that.

## Run it locally

```bash
pip install -r requirements.txt
pip install gradio
python app.py
```

Then open the link it prints (usually http://localhost:7860).

## Use your own documents

Upload `.txt`, `.md`, or `.pdf` files in the app and click **Build index from these** — it
re-indexes on the spot and you can ask questions about your own material.

## Project layout

```
app.py              ← the Gradio interface
rag/ingest.py       ← read + chunk documents (txt, md, pdf)
rag/store.py        ← embeddings + FAISS vector search
rag/generate.py     ← the answer model (local flan-t5; optional hosted LLM)
rag/pipeline.py     ← retrieve → prompt → generate, with sources
data/*.md           ← the built-in knowledge base
```

## A note

This was authored carefully but, like any project, may want a small version nudge on first
build (a dependency, a Gradio version). If the Space build complains, bump `sdk_version` above
or relax a pin in `requirements.txt` — or open the folder in Claude Code and let it sort the
build out.
