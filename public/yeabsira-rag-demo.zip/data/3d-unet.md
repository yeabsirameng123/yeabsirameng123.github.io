# 3D U-Net and volumetric segmentation

Many medical scans are three-dimensional. An MRI or CT study is a stack of 2D slices that
together form a volume, where each element is a voxel (the 3D equivalent of a pixel). The 3D
U-Net extends the original U-Net so it can segment these volumes directly.

## What changes from 2D to 3D

The structure is the same U shape with an encoder, a decoder, and skip connections. The
difference is that 2D operations become 3D ones: 3D convolutions, 3D pooling, and 3D
upsampling. A 3D convolution slides a small cube of weights through the volume, so the network
can see context across slices, not just within a single slice.

## Why 3D helps

A tumor, an organ, or a lesion is a 3D structure. Looking at one slice at a time discards the
relationship between neighbouring slices. Working in 3D lets the model use that vertical
context, which usually improves how consistent and accurate the segmentation is from slice to
slice.

## The memory problem

The main cost of going 3D is memory. A 3D convolution and its feature maps use far more memory
than the 2D version, so it is often impossible to fit a whole high-resolution volume and a deep
network into GPU memory at once.

The common workaround is patch-based training: instead of feeding the whole volume, you sample
smaller 3D patches (sub-volumes) from it, train on those, and reassemble the predictions at
inference time. Choosing how to sample patches matters. Sampling uniformly tends to flood the
model with background, so patches are often sampled to ensure enough of them contain the
structure of interest. Batch sizes in 3D are usually small for the same memory reasons.
