"""Embed chunks with a sentence-transformer and search them with FAISS (cosine similarity)."""
import numpy as np

EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

_embedder = None


def get_embedder():
    """Load the embedding model once and reuse it."""
    global _embedder
    if _embedder is None:
        from sentence_transformers import SentenceTransformer
        _embedder = SentenceTransformer(EMBED_MODEL)
    return _embedder


class VectorStore:
    """An in-memory FAISS index over a list of text chunks."""

    def __init__(self):
        self.index = None
        self.chunks = []

    def build(self, chunks):
        """chunks: list of {text, source}. Embeds them and builds a cosine index."""
        import faiss

        self.chunks = list(chunks)
        if not self.chunks:
            self.index = None
            return 0

        texts = [c["text"] for c in self.chunks]
        emb = get_embedder().encode(
            texts,
            normalize_embeddings=True,      # cosine similarity via inner product
            convert_to_numpy=True,
            show_progress_bar=False,
        ).astype("float32")

        self.index = faiss.IndexFlatIP(emb.shape[1])
        self.index.add(emb)
        return len(self.chunks)

    def search(self, query, k=3):
        """Return the top-k (chunk, score) pairs for a query string."""
        if self.index is None or not self.chunks:
            return []
        q = get_embedder().encode(
            [query], normalize_embeddings=True, convert_to_numpy=True
        ).astype("float32")
        k = min(k, len(self.chunks))
        scores, idx = self.index.search(q, k)
        results = []
        for rank, i in enumerate(idx[0]):
            if i != -1:
                results.append((self.chunks[i], float(scores[0][rank])))
        return results
