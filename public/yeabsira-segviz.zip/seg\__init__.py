"""SegViz — semantic segmentation inference and visualization."""
