"""Ask My Docs — a Gradio interface for the RAG pipeline."""
import os
import glob
import gradio as gr

from rag.pipeline import RAGPipeline

HERE = os.path.dirname(os.path.abspath(__file__))

# Build the default index from the bundled knowledge base on startup.
pipe = RAGPipeline()
_default_paths = sorted(glob.glob(os.path.join(HERE, "data", "*")))
_default_count = pipe.index_paths(_default_paths)
_index_label = f"Built-in knowledge base · {_default_count} passages indexed"

HEADER = """
# 🧠 Ask My Docs
A retrieval-augmented question answering demo. It finds the most relevant passages in a
document collection, then answers **using only those passages** — and shows the sources, so
the answer stays grounded. Everything runs locally: MiniLM embeddings, a FAISS index, and a
flan-t5 model. No API keys.

It starts loaded with notes on **deep learning for medical image segmentation**. Ask one of
the examples, or upload your own `.txt`, `.md`, or `.pdf` on the right.
"""

EXAMPLES = [
    "What is a U-Net and why is it good for segmentation?",
    "Why use a 3D U-Net for MRI instead of a 2D one?",
    "How is the Dice score calculated?",
    "Which MRI modalities help with brain tumor segmentation?",
    "What kinds of data augmentation help in medical imaging?",
    "What loss functions work well for segmentation?",
]

CSS = """
.gradio-container { max-width: 1100px !important; }
#answer-box { min-height: 90px; }
footer { display: none !important; }
"""


def ask(question):
    question = (question or "").strip()
    if not question:
        return "Type a question above to get started.", ""
    answer, sources = pipe.answer(question)
    if sources:
        src_md = "\n\n".join(
            f"**{s['source']}**  ·  similarity {s['score']}\n\n> "
            + s["text"][:320].replace("\n", " ")
            + ("…" if len(s["text"]) > 320 else "")
            for s in sources
        )
    else:
        src_md = ""
    return answer, src_md


def rebuild(files):
    if not files:
        return "No files uploaded yet.", gr.update()
    paths = [getattr(f, "name", f) for f in files]
    n = pipe.index_paths(paths)
    if n == 0:
        return "Couldn't read any text from those files. Try .txt, .md, or a text-based PDF.", gr.update()
    names = ", ".join(os.path.basename(p) for p in paths)
    return f"Indexed {n} passages from {len(paths)} file(s): {names}. Ask away.", gr.update()


def reset_default():
    n = pipe.index_paths(_default_paths)
    return f"Back to the built-in knowledge base · {n} passages indexed."


with gr.Blocks(theme=gr.themes.Soft(primary_hue="indigo"), css=CSS, title="Ask My Docs — RAG") as demo:
    gr.Markdown(HEADER)

    with gr.Row():
        with gr.Column(scale=3):
            question = gr.Textbox(
                label="Ask a question",
                placeholder="e.g. How is the Dice score calculated?",
                lines=2,
            )
            ask_btn = gr.Button("Ask", variant="primary")
            answer = gr.Markdown(elem_id="answer-box")
            with gr.Accordion("Sources the answer used", open=False):
                sources = gr.Markdown()
            gr.Examples(examples=EXAMPLES, inputs=question, label="Try one")

        with gr.Column(scale=2):
            gr.Markdown("### Use your own documents")
            gr.Markdown(
                "Upload files to index them, then ask questions about them instead of the "
                "built-in notes."
            )
            uploads = gr.File(
                file_count="multiple",
                file_types=[".txt", ".md", ".pdf"],
                type="filepath",
                label="Upload .txt, .md, or .pdf",
            )
            build_btn = gr.Button("Build index from these", variant="primary")
            reset_btn = gr.Button("Reset to built-in notes")
            status = gr.Markdown(_index_label)

    ask_btn.click(ask, inputs=question, outputs=[answer, sources])
    question.submit(ask, inputs=question, outputs=[answer, sources])
    build_btn.click(rebuild, inputs=uploads, outputs=[status, uploads])
    reset_btn.click(reset_default, outputs=status)

    gr.Markdown(
        "<br><sub>Built by Yeabsira Dana · embeddings: all-MiniLM-L6-v2 · "
        "retrieval: FAISS · generation: flan-t5-base</sub>"
    )

demo.queue()

if __name__ == "__main__":
    demo.launch()
