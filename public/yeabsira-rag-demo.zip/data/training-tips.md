# Loss functions and training for segmentation

The loss function defines what the network is rewarded for during training. In segmentation,
the choice of loss is closely tied to the class-imbalance problem, since the target structure
usually occupies only a small part of the image.

## Cross-entropy loss

Per-voxel cross-entropy is the standard classification loss applied to every voxel
independently. It is simple and stable, but on imbalanced data it can be dominated by the
abundant background class, so the model is barely penalized for missing the small structure.
Weighted cross-entropy partly fixes this by giving the rare class a higher weight.

## Dice loss

Dice loss is derived directly from the Dice overlap metric (1 minus the Dice coefficient,
written in a differentiable form). Because it measures overlap of the target region, it is
naturally robust to imbalance — it focuses on the structure being segmented rather than the
background. The trade-off is that it can be less stable early in training when predictions are
poor.

## Combined losses

A very common and effective choice is to add the two together — for example Dice loss plus
cross-entropy. This gives the stable, well-behaved gradients of cross-entropy alongside the
imbalance-robust, overlap-focused signal of Dice. Other variants such as Tversky loss let you
tune the relative penalty on false positives versus false negatives, which is useful when
missing the structure is worse than over-segmenting it.

## Training practicalities

Segmentation models are usually trained with the Adam optimizer and a learning-rate schedule
that decays over time. Validation is tracked with the Dice score rather than the loss, since
Dice is what people actually care about. Because 3D data and patch sampling make each epoch
expensive, early stopping and saving the best-validation checkpoint are standard, and careful
preprocessing and augmentation often matter more to the final score than small changes to the
network architecture.
