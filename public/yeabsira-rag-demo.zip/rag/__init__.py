"""A small, transparent Retrieval-Augmented Generation pipeline."""
from .pipeline import RAGPipeline

__all__ = ["RAGPipeline"]
