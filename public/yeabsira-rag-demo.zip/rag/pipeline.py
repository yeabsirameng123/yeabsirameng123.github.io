"""Tie retrieval and generation together into one pipeline."""
from .store import VectorStore
from .ingest import load_corpus, chunk_text
from .generate import generate_answer


class RAGPipeline:
    def __init__(self):
        self.store = VectorStore()

    def index_paths(self, paths):
        """Index a list of file paths. Returns the number of chunks indexed."""
        chunks = load_corpus(paths)
        return self.store.build(chunks)

    def index_texts(self, items):
        """Index a list of (text, source) tuples. Returns the number of chunks indexed."""
        chunks = []
        for text, source in items:
            chunks.extend(chunk_text(text, source))
        return self.store.build(chunks)

    def answer(self, question, k=3):
        """Return (answer_text, sources). `sources` is a list of {source, score, text}."""
        hits = self.store.search(question, k=k)
        if not hits:
            return "No documents are indexed yet. Upload a file or use the built-in set.", []

        contexts = [chunk["text"] for chunk, _ in hits]
        answer = generate_answer(question, contexts)
        sources = [
            {"source": chunk["source"], "score": round(score, 3), "text": chunk["text"]}
            for chunk, score in hits
        ]
        return answer, sources
