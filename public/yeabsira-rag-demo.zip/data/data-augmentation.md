# Data augmentation and data generators

Medical imaging datasets are usually small, because every label needs an expert to draw it.
Data augmentation fights the resulting overfitting by generating new, plausible training
examples from the ones you already have, so the model sees more variety without new labels.

## Common augmentations

Geometric transforms are the workhorses: random flips, rotations, scaling, and elastic
deformations that warp the image slightly. Elastic deformation is especially useful for
biomedical images because real anatomy varies in shape, and it was highlighted in the original
U-Net work. Intensity transforms also help: adjusting brightness and contrast, adding noise, or
simulating bias fields that mimic MRI scanner artifacts. Whatever transform is applied to the
image must be applied identically to its segmentation mask so they stay aligned.

## Class imbalance

In most scans the target — a tumor, a lesion — occupies a tiny fraction of the voxels. If
training samples are drawn uniformly, the model mostly sees background and learns to predict
background. Two standard fixes are to weight the loss so errors on the rare class count more,
and to sample patches so that a healthy share of them actually contain the structure of
interest.

## Data generators

For large datasets, especially 3D volumes, you cannot hold everything in memory at once. A data
generator streams batches on demand: it loads the raw data, applies preprocessing and
augmentation on the fly, and yields one batch at a time during training. A well-designed
generator is where a lot of practical performance comes from — it controls how patches are
sampled, how augmentation is applied, and how class balance is handled, all of which directly
shape what the model learns. Customizing the generator is often a more effective lever than
changing the network itself.

## Preprocessing

Before augmentation, scans are typically normalized so intensity values are on a consistent
scale across patients and scanners — for example, z-score normalization within the brain
region. Consistent preprocessing reduces the variation the model has to absorb and makes
training more stable.
