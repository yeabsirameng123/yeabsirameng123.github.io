"""SegViz - a Gradio interface for semantic segmentation."""
import hashlib

import gradio as gr

from seg.model import segment
from seg.visualize import build_palette, coverage, make_overlay

PALETTE = build_palette(256)

HEADER = """
# SegViz - semantic segmentation
Upload an image and a SegFormer transformer labels every pixel with the object it belongs to.
You get a color overlay, a fade slider, and a ranked breakdown of what is in the scene.

Runs locally on a free CPU Hugging Face Space. No API keys, no external inference service.
Best on everyday scenes: streets, rooms, landscapes, people, buildings, plants, and vehicles.
"""

CSS = """
.gradio-container { max-width: 1120px !important; }
footer { display: none !important; }
.legend-row { display:flex; align-items:center; gap:10px; padding:5px 0; font-size:0.95rem; }
.swatch { width:16px; height:16px; border-radius:4px; flex:none; border:1px solid rgba(0,0,0,0.15); }
.bar { height:8px; border-radius:4px; }
.model-note { color:#64748b; font-size:0.88rem; }
"""


def image_signature(image):
    """Create a stable signature so slider changes can reuse the latest mask."""
    rgb = image.convert("RGB")
    return (rgb.size, hashlib.sha256(rgb.tobytes()).hexdigest())


def legend_html(rows):
    if not rows:
        return ""

    out = ['<div style="margin-top:6px">']
    for label, hexcol, pct in rows:
        out.append(
            '<div class="legend-row">'
            f'<span class="swatch" style="background:{hexcol}"></span>'
            f'<span style="min-width:150px">{label}</span>'
            f'<span style="flex:1; max-width:260px"><span class="bar" '
            f'style="display:block; width:{min(pct,100)}%; background:{hexcol}"></span></span>'
            f'<span style="color:#666; min-width:52px; text-align:right">{pct}%</span>'
            "</div>"
        )
    out.append("</div>")
    return "".join(out)


def build_result(image, alpha, state=None):
    if image is None:
        return None, "Upload an image to segment it.", state

    signature = image_signature(image)
    if state and state.get("signature") == signature:
        class_map = state["class_map"]
        id2label = state["id2label"]
    else:
        class_map, id2label = segment(image)
        state = {
            "signature": signature,
            "class_map": class_map,
            "id2label": id2label,
        }

    overlay = make_overlay(image, class_map, PALETTE, alpha=alpha)
    rows = coverage(class_map, id2label, PALETTE)
    return overlay, legend_html(rows), state


with gr.Blocks(
    theme=gr.themes.Soft(primary_hue="indigo"),
    css=CSS,
    title="SegViz - Semantic Segmentation",
) as demo:
    mask_state = gr.State()
    gr.Markdown(HEADER)

    with gr.Row():
        with gr.Column():
            image_in = gr.Image(type="pil", label="Input image", height=380)
            alpha = gr.Slider(0.15, 0.9, value=0.55, step=0.05, label="Overlay strength")
            run_btn = gr.Button("Segment image", variant="primary")
            gr.Markdown(
                '<p class="model-note">Model: nvidia/segformer-b0-finetuned-ade-512-512 '
                '(ADE20K, 150 scene classes). Slider changes reuse the cached mask.</p>'
            )
        with gr.Column():
            overlay_out = gr.Image(type="pil", label="Segmentation overlay", height=380)
            gr.Markdown("**Scene coverage**")
            legend = gr.HTML()

    run_btn.click(
        build_result,
        inputs=[image_in, alpha, mask_state],
        outputs=[overlay_out, legend, mask_state],
    )
    alpha.release(
        build_result,
        inputs=[image_in, alpha, mask_state],
        outputs=[overlay_out, legend, mask_state],
    )

    gr.Markdown(
        "<br><sub>Built by Yeabsira Dana. This project connects browser-ready scene parsing "
        "with my published work on 3D medical-image segmentation.</sub>"
    )

demo.queue()

if __name__ == "__main__":
    demo.launch()
